function BaseballCard(props) {
  return (
    <div className="card">
      <h2>Player Name goes here</h2>
    </div>
  );
}

function App() {
  return <BaseballCard />;
}

export default App;
